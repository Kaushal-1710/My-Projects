<?php
$con = mysqli_connect("localhost","root", "", "inferno_co");
?>